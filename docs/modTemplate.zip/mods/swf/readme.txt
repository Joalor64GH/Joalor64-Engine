Your SWF movies go here!
Make sure they are in the .swf format (obviously)!