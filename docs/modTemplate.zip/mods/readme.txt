You can either edit files or add entirely new ones here.

ABOUT EDITTING:
It doesn't matter if you want to edit something in assets/shared/images/ or assets/preload/images/.
Either way, you will have to put the edited files in mods/images/, since it will be handled automatically by the engine.
Also, if you edit any of the regular assets and move it to the mods folder, it will override the vanilla assets.
