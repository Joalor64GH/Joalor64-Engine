Your haxe states go here!
They have to be in the .hscript format!