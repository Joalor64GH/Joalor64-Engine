Your custom states go here!
They must be in the .hx format or else they won't work!