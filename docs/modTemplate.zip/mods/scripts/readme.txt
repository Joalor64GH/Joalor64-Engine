Add your custom .lua and .hscript scripts here! Be sure to also put them in scriptsList.txt!
Scripts in this folder will be loaded on all songs, no matter the difficulty, song name, or week.

If you've put it inside a modpack, the script will be running, as long as the modpack is enabled.