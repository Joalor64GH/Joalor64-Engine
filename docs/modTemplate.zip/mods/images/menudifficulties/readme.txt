Put your custom difficulties here in the form of a .png.
The file MUST be 314 x 104.
