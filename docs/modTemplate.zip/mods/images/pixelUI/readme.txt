Put your custom pixel assets here.
Preferably arrows.
