Drop your dialogue portraits here.

If you're asking "How do I get the things working?", try reading this:
https://github.com/ShadowMario/FNF-PsychEngine/wiki/Dialogues