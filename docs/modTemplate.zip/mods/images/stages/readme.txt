Put stages here.
If they have the path "mods/images/stages" OR "mods/my-mod/images/stages", that is.
