Put stages here.
Specifically stages from MFM Deluxe.
