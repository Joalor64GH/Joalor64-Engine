Put your custom character icons here!
Your icon must start with "icon-" or it won't be read!
The image resolution must be 300x150.