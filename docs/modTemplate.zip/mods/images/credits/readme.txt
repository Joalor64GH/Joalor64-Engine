Put your custom credit icons here!
And don't forget to put your custom credits in mods/data!
