Put your custom credit icons here!
They have to be 140x150!
And don't forget to put your custom credits in mods/data!