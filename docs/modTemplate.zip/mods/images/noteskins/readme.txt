Place assets for custom notes here!
Otherwise they won't display properly!