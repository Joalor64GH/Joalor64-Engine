Put your custom charts here!
They must be in a .json file.
For credits, read the wiki for information.
https://github.com/Joalor64GH/Joalor64-Engine/wiki/Modding#credits