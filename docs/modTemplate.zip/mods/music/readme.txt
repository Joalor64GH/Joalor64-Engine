Drop you custom music here!
The music should be in an .ogg file, otherwise it won't work!!

QUICK NOTE!
This is not about your custom song's music (Instrumental or Voices).
If you want to implement your custom song, go to "mods/songs/".

This is for being used with Lua's "playMusic".