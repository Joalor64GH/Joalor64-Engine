Place your custom fonts here!
If your font is named "yourfont.ttf", you can make lua texts use it by typing in the following:

setTextFont("yourObjectTag", "yourfont.ttf");