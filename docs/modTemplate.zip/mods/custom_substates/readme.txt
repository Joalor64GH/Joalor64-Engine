Your custom substates go here!
Make sure they're in the HX format!!