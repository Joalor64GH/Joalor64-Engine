Your haxescript modcharts go here!
Make sure they're in the .hx format!